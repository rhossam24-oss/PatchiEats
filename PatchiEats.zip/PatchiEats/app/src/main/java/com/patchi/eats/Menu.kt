package com.patchi.eats

// ✏️ عدّل الأصناف والأسعار من هنا
data class MenuItem(
    val id: String,
    val nameEn: String,
    val nameAr: String,
    val descEn: String,
    val descAr: String,
    val categoryEn: String,
    val categoryAr: String,
    val price: Double
)

val MENU: List<MenuItem> = listOf(
    MenuItem(
        id = "patchi_chocolate_molten",
        nameEn = "Chocolate Molten Cake",
        nameAr = "مولتن كيك الشوكولاتة",
        descEn = "Warm Belgian dark chocolate fondant with a flowing cocoa heart and vanilla bean gelato.",
        descAr = "كيك شوكولاتة بلجيكية دافئة بقلب شوكولاتة سائل وآيس كريم الفانيليا.",
        categoryEn = "Desserts",
        categoryAr = "الحلويات",
        price = 265.0
    ),
    MenuItem(
        id = "patchi_chocolate_bomb",
        nameEn = "Patchi Chocolate Bomb",
        nameAr = "قنبلة الشوكولاتة من باتشي",
        descEn = "Tempered chocolate sphere melted tableside with warm salted caramel ganache and hazelnut praline.",
        descAr = "كرة شوكولاتة فاخرة تذوب مع صوص الكراميل المملح الدافئ وبرالين البندق.",
        categoryEn = "Desserts",
        categoryAr = "الحلويات",
        price = 295.0
    ),
    MenuItem(
        id = "patchi_san_sebastian",
        nameEn = "San Sebastian Cheesecake",
        nameAr = "تشيز كيك سان سيباستيان",
        descEn = "Caramelized Basque cheesecake drizzled with melted Patchi milk & dark chocolate.",
        descAr = "تشيز كيك باسك مكرمل مغطى بشوكولاتة باتشي بالحليب والداكنة المذابة.",
        categoryEn = "Desserts",
        categoryAr = "الحلويات",
        price = 285.0
    ),
    MenuItem(
        id = "patchi_libanaise_deux",
        nameEn = "Libanaise à Deux Breakfast",
        nameAr = "إفطار لبناني لشخصين",
        descEn = "Artisanal halloumi, labneh, za'atar flatbread, farm eggs, olives, and fresh garden platter.",
        descAr = "جبن حلومي مشوي، لبنة طازجة، مناقيش زعتر، بيض مزارع، زيتون وخضروات طازجة.",
        categoryEn = "Breakfast",
        categoryAr = "الإفطار",
        price = 390.0
    ),
    MenuItem(
        id = "patchi_international_breakfast",
        nameEn = "International Breakfast",
        nameAr = "الإفطار العالمي",
        descEn = "Grilled beef sausage with bell peppers, olives, BBQ glaze, buttered toast, and cheesy potatoes.",
        descAr = "سجق بقري مشوي مع فلفل ألوان وزيتون وصوص باربكيو وتوست محمص وبطاطس بالجبن.",
        categoryEn = "Breakfast",
        categoryAr = "الإفطار",
        price = 420.0
    ),
    MenuItem(
        id = "patchi_salmon_scandal",
        nameEn = "Salmon Scandal Benedict",
        nameAr = "سالمون سكاندال بينيديكت",
        descEn = "Smoked Norwegian salmon on toasted brioche with poached eggs and citrus hollandaise.",
        descAr = "سلمون نرويجي مدخن على خبز البريوش المحمص مع بيض مسلوق وصوص هولانديز.",
        categoryEn = "Breakfast",
        categoryAr = "الإفطار",
        price = 365.0
    ),
    MenuItem(
        id = "patchi_toast_mixed_cheese",
        nameEn = "Toast Mixed Cheese & Thyme",
        nameAr = "توست ميكس جبن وزعتر",
        descEn = "Crisp sourdough pressed with three melted artisanal cheeses and fragrant wild thyme.",
        descAr = "خبز ساوردو مقرمش محشو بثلاثة أنواع جبن ذائبة مع الزعتر البري العطري.",
        categoryEn = "Breakfast",
        categoryAr = "الإفطار",
        price = 215.0
    ),
    MenuItem(
        id = "patchi_truffle_pizzette",
        nameEn = "Truffle Wild Mushroom Pizzette",
        nameAr = "بيتزيت الفطر البري بالكمأة",
        descEn = "Stone-baked thin crust with roasted portobello, fontina cheese, and black truffle crema.",
        descAr = "عجينة رقيقة مخبوزة على الحجر مع فطر بورتوبيلو وجبن فونتينا وكريمة الكمأة السوداء.",
        categoryEn = "Mains & Grills",
        categoryAr = "الأطباق الرئيسية",
        price = 385.0
    ),
    MenuItem(
        id = "patchi_chicken_katsu_sando",
        nameEn = "Crispy Chicken Katsu Sando",
        nameAr = "ساندو دجاج كاتسو مقرمش",
        descEn = "Panko-crusted tender chicken breast on milk bread with sesame slaw and yuzu mayo.",
        descAr = "صدر دجاج مقرمش بالبانكو في خبز الحليب مع سلطة السمسم ومايونيز اليوزو.",
        categoryEn = "Mains & Grills",
        categoryAr = "الأطباق الرئيسية",
        price = 340.0
    ),
    MenuItem(
        id = "patchi_caesar_salad",
        nameEn = "Chargrilled Chicken Caesar",
        nameAr = "سلطة سيزر بالدجاج المشوي",
        descEn = "Crisp baby romaine, aged parmesan shards, herb croutons, and roasted garlic Caesar dressing.",
        descAr = "خس روماني مقرمش مع شرائح جبن البارميزان، خبز محمص بالأعشاب ودجاج مشوي.",
        categoryEn = "Salads",
        categoryAr = "السلطات",
        price = 290.0
    ),
    MenuItem(
        id = "patchi_acai_granola",
        nameEn = "Red Fruits Granola & Açai Bowl",
        nameAr = "وعاء جرانولا الفواكه الحمراء والأساي",
        descEn = "Organic Amazonian açai topped with toasted oat clusters, fresh berries, and chia seeds.",
        descAr = "أساي عضوي مع جرانولا الشوفان المحمص والتوت الطازج وبذور الشيا.",
        categoryEn = "Healthy Corner",
        categoryAr = "الركن الصحي",
        price = 240.0
    ),
    MenuItem(
        id = "patchi_dark_hot_chocolate",
        nameEn = "Signature Dark Hot Chocolate",
        nameAr = "هوت شوكليت باتشي الداكن",
        descEn = "Velvety 70% single-origin melted Patchi cocoa whisked into steamed microfoam.",
        descAr = "كاكاو باتشي الداكن الفاخر بنسبة 70% مخفوق مع حليب مبخر ناعم.",
        categoryEn = "Specialty Coffee",
        categoryAr = "القهوة والمشروبات الساخنة",
        price = 155.0
    ),
    MenuItem(
        id = "patchi_matcha_latte",
        nameEn = "Ceremonial Uji Matcha Latte",
        nameAr = "ماتشا لاتيه ياباني فاخر",
        descEn = "Stone-ground Japanese green tea whisked with silky oat or dairy milk.",
        descAr = "شاي الماتشا الياباني الأخضر المطحون بالحجر مع الحليب الكريمي.",
        categoryEn = "Specialty Coffee",
        categoryAr = "القهوة والمشروبات الساخنة",
        price = 165.0
    ),
    MenuItem(
        id = "patchi_lotus_milkshake",
        nameEn = "Salted Caramel & Lotus Shake",
        nameAr = "ميلك شيك كراميل مملح ولوتس",
        descEn = "Hand-spun vanilla bean ice cream blended with caramelized biscuit butter and espresso shot.",
        descAr = "آيس كريم الفانيليا ممزوج بزبدة اللوتس والكراميل المملح وجرعة إسبريسو.",
        categoryEn = "Cold Drinks",
        categoryAr = "المشروبات الباردة",
        price = 175.0
    )
)

val MENU_BY_ID: Map<String, MenuItem> = MENU.associateBy { it.id }
