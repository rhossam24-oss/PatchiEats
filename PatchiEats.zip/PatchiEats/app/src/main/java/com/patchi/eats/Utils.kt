package com.patchi.eats

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import java.util.Locale

enum class Lang { AR, EN }

enum class PayMethod { INSTAPAY, WALLET, CASH }

data class Profile(val name: String, val phone: String, val address: String)

fun tr(lang: Lang, ar: String, en: String): String = if (lang == Lang.AR) ar else en

fun money(value: Double, lang: Lang): String {
    val num = if (value % 1.0 == 0.0) value.toLong().toString() else String.format(Locale.US, "%.2f", value)
    return if (lang == Lang.AR) "$num ج.م" else "EGP $num"
}

fun payLabel(method: PayMethod, lang: Lang): String = when (method) {
    PayMethod.INSTAPAY -> tr(lang, "إنستاباي (QR)", "InstaPay (QR)")
    PayMethod.WALLET -> tr(lang, "محفظة إلكترونية", "Mobile wallet")
    PayMethod.CASH -> tr(lang, "كاش عند الاستلام", "Cash on delivery")
}

// ---------- Cart ----------
fun addToCart(cart: MutableMap<String, Int>, id: String) {
    cart[id] = (cart[id] ?: 0) + 1
}

fun removeFromCart(cart: MutableMap<String, Int>, id: String) {
    val q = (cart[id] ?: 0) - 1
    if (q <= 0) cart.remove(id) else cart[id] = q
}

fun cartSubtotal(cart: Map<String, Int>): Double {
    var sum = 0.0
    for ((id, q) in cart) {
        sum += (MENU_BY_ID[id]?.price ?: 0.0) * q
    }
    return sum
}

// ---------- Phone ----------
private val EGYPT_MOBILE = Regex("^01[0125][0-9]{8}$")

/** Converts Arabic digits to English, removes spaces/symbols and +20 prefix. */
fun normalizePhone(input: String): String {
    val sb = StringBuilder()
    for (c in input) {
        when (c) {
            in '٠'..'٩' -> sb.append('0' + (c - '٠'))
            in '۰'..'۹' -> sb.append('0' + (c - '۰'))
            in '0'..'9' -> sb.append(c)
        }
    }
    var p = sb.toString()
    if (p.startsWith("20") && p.length == 12) p = "0" + p.substring(2)
    return p
}

fun isValidPhone(phone: String): Boolean = EGYPT_MOBILE.matches(phone)

// ---------- Order ----------
fun newOrderId(): String = (System.currentTimeMillis() % 1_000_000).toString().padStart(6, '0')

/** WhatsApp message to the restaurant (always Arabic). */
fun buildOrderMessage(
    orderId: String,
    profile: Profile,
    cart: Map<String, Int>,
    notes: String,
    pay: PayMethod
): String {
    val ar = Lang.AR
    val subtotal = cartSubtotal(cart)
    val total = subtotal + Config.DELIVERY_FEE
    val line = "━━━━━━━━━━━━"
    val sb = StringBuilder()
    sb.append("🧾 طلب جديد - ${Config.RESTAURANT_NAME_AR}\n")
    sb.append("رقم الطلب: #$orderId\n")
    sb.append("$line\n")
    sb.append("👤 الاسم: ${profile.name}\n")
    sb.append("📞 الموبايل: ${profile.phone}\n")
    sb.append("📍 العنوان: ${profile.address}\n")
    sb.append("$line\n")
    sb.append("🍽️ الأصناف:\n")
    for ((id, q) in cart) {
        val item = MENU_BY_ID[id] ?: continue
        sb.append("• $q × ${item.nameAr} = ${money(item.price * q, ar)}\n")
    }
    sb.append("$line\n")
    sb.append("المجموع: ${money(subtotal, ar)}\n")
    sb.append("التوصيل: ${money(Config.DELIVERY_FEE, ar)}\n")
    sb.append("💰 الإجمالي: ${money(total, ar)}\n")
    sb.append("💳 طريقة الدفع: ${payLabel(pay, ar)}\n")
    if (notes.isNotBlank()) sb.append("📝 ملاحظات: ${notes.trim()}\n")
    sb.append("$line\n")
    sb.append("برجاء تأكيد الطلب ومدة التوصيل.")
    return sb.toString()
}

fun openWhatsApp(context: Context, phone: String, text: String): Boolean {
    val uri = Uri.parse("https://wa.me/$phone?text=" + Uri.encode(text))
    return try {
        context.startActivity(Intent(Intent.ACTION_VIEW, uri))
        true
    } catch (e: ActivityNotFoundException) {
        false
    }
}

fun copyToClipboard(context: Context, text: String, toast: String) {
    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("patchi", text))
    Toast.makeText(context, toast, Toast.LENGTH_SHORT).show()
}

// ---------- Saved data ----------
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("patchi_eats", Context.MODE_PRIVATE)

    var lang: Lang
        get() = if (sp.getString("lang", "ar") == "en") Lang.EN else Lang.AR
        set(value) {
            sp.edit().putString("lang", if (value == Lang.EN) "en" else "ar").apply()
        }

    fun loadProfile(): Profile? {
        val name = sp.getString("name", null) ?: return null
        val phone = sp.getString("phone", null) ?: return null
        val address = sp.getString("address", null) ?: return null
        return Profile(name, phone, address)
    }

    fun saveProfile(p: Profile) {
        sp.edit()
            .putString("name", p.name)
            .putString("phone", p.phone)
            .putString("address", p.address)
            .apply()
    }
}
