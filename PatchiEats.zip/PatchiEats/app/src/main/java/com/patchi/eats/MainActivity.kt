package com.patchi.eats

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateMap
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Brown = Color(0xFF5D3A1A)
private val Gold = Color(0xFFC9A227)
private val Cream = Color(0xFFFFF8F0)

private val PatchiColors = lightColorScheme(
    primary = Brown,
    onPrimary = Color.White,
    secondary = Gold,
    onSecondary = Color.White,
    background = Cream,
    surface = Color.White
)

enum class Screen { REGISTER, MENU, CHECKOUT, DONE }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = Prefs(this)
        setContent { PatchiApp(prefs) }
    }
}

@Composable
fun PatchiApp(prefs: Prefs) {
    var lang by remember { mutableStateOf(prefs.lang) }
    var profile by remember { mutableStateOf(prefs.loadProfile()) }
    var screen by remember { mutableStateOf(if (profile == null) Screen.REGISTER else Screen.MENU) }
    var registerReturn by remember { mutableStateOf(Screen.MENU) }
    var lastOrderId by remember { mutableStateOf("") }
    val cart = remember { mutableStateMapOf<String, Int>() }

    val toggleLang: () -> Unit = {
        lang = if (lang == Lang.AR) Lang.EN else Lang.AR
        prefs.lang = lang
    }

    BackHandler(enabled = screen == Screen.CHECKOUT || screen == Screen.DONE || (screen == Screen.REGISTER && profile != null)) {
        screen = if (screen == Screen.REGISTER) registerReturn else Screen.MENU
    }

    val direction = if (lang == Lang.AR) LayoutDirection.Rtl else LayoutDirection.Ltr
    CompositionLocalProvider(LocalLayoutDirection provides direction) {
        MaterialTheme(colorScheme = PatchiColors) {
            Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                when (screen) {
                    Screen.REGISTER -> RegisterScreen(
                        lang = lang,
                        initial = profile,
                        onToggleLang = toggleLang,
                        onBack = if (profile != null) ({ screen = registerReturn }) else null,
                        onSave = { p ->
                            prefs.saveProfile(p)
                            profile = p
                            screen = registerReturn
                        }
                    )

                    Screen.MENU -> MenuScreen(
                        lang = lang,
                        cart = cart,
                        onToggleLang = toggleLang,
                        onProfile = {
                            registerReturn = Screen.MENU
                            screen = Screen.REGISTER
                        },
                        onOpenCart = { screen = Screen.CHECKOUT }
                    )

                    Screen.CHECKOUT -> {
                        val p = profile
                        if (p != null) {
                            CheckoutScreen(
                                lang = lang,
                                cart = cart,
                                profile = p,
                                onToggleLang = toggleLang,
                                onBack = { screen = Screen.MENU },
                                onEditProfile = {
                                    registerReturn = Screen.CHECKOUT
                                    screen = Screen.REGISTER
                                },
                                onSent = { id ->
                                    lastOrderId = id
                                    screen = Screen.DONE
                                    cart.clear()
                                }
                            )
                        }
                    }

                    Screen.DONE -> DoneScreen(
                        lang = lang,
                        orderId = lastOrderId,
                        onToggleLang = toggleLang,
                        onNewOrder = { screen = Screen.MENU }
                    )
                }
            }
        }
    }
}

// ================= Common =================

@Composable
fun Header(
    title: String,
    lang: Lang,
    onToggleLang: () -> Unit,
    onBack: (() -> Unit)? = null,
    actions: @Composable RowScope.() -> Unit = {}
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Brown)
            .padding(horizontal = 6.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            TextButton(onClick = onBack) {
                Text(if (lang == Lang.AR) "→" else "←", color = Color.White, fontSize = 22.sp)
            }
        }
        Text(
            text = title,
            color = Color.White,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 8.dp)
        )
        actions()
        TextButton(onClick = onToggleLang) {
            Text(if (lang == Lang.AR) "EN" else "عربي", color = Gold, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(
        text = text,
        fontSize = 18.sp,
        fontWeight = FontWeight.Bold,
        color = Brown,
        modifier = Modifier.padding(top = 16.dp, bottom = 8.dp)
    )
}

@Composable
fun QtyControl(qty: Int, lang: Lang, onAdd: () -> Unit, onRemove: () -> Unit) {
    if (qty == 0) {
        Button(onClick = onAdd) { Text(tr(lang, "إضافة", "Add")) }
    } else {
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(
                onClick = onRemove,
                contentPadding = PaddingValues(0.dp),
                modifier = Modifier.size(40.dp)
            ) { Text("−", fontSize = 20.sp) }
            Text(
                text = qty.toString(),
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 14.dp)
            )
            Button(
                onClick = onAdd,
                contentPadding = PaddingValues(0.dp),
                modifier = Modifier.size(40.dp)
            ) { Text("+", fontSize = 20.sp) }
        }
    }
}

@Composable
fun AmountRow(label: String, value: String, bold: Boolean = false) {
    Row(modifier = Modifier
        .fillMaxWidth()
        .padding(vertical = 3.dp)) {
        Text(
            label,
            modifier = Modifier.weight(1f),
            fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
            fontSize = if (bold) 18.sp else 15.sp
        )
        Text(
            value,
            fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
            fontSize = if (bold) 18.sp else 15.sp,
            color = if (bold) Brown else Color.Unspecified
        )
    }
}

// ================= Register =================

@Composable
fun RegisterScreen(
    lang: Lang,
    initial: Profile?,
    onToggleLang: () -> Unit,
    onBack: (() -> Unit)?,
    onSave: (Profile) -> Unit
) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var phone by remember { mutableStateOf(initial?.phone ?: "") }
    var address by remember { mutableStateOf(initial?.address ?: "") }
    var error by remember { mutableStateOf<String?>(null) }

    Column(modifier = Modifier.fillMaxSize()) {
        Header(tr(lang, "بياناتك", "Your details"), lang, onToggleLang, onBack = onBack)
        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                tr(lang, "سجّل برقم موبايلك عشان نوصلك الطلب", "Register with your mobile number so we can deliver your order"),
                fontSize = 16.sp
            )
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text(tr(lang, "الاسم", "Name")) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = phone,
                onValueChange = { phone = it },
                label = { Text(tr(lang, "رقم الموبايل", "Mobile number")) },
                placeholder = { Text("01xxxxxxxxx") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = address,
                onValueChange = { address = it },
                label = { Text(tr(lang, "العنوان بالتفصيل", "Full address")) },
                minLines = 2,
                modifier = Modifier.fillMaxWidth()
            )
            val err = error
            if (err != null) {
                Text(err, color = MaterialTheme.colorScheme.error)
            }
            Button(
                onClick = {
                    val p = normalizePhone(phone)
                    when {
                        name.isBlank() -> error = tr(lang, "اكتب اسمك", "Enter your name")
                        !isValidPhone(p) -> error = tr(lang, "رقم الموبايل لازم يكون 11 رقم ويبدأ بـ 01", "Mobile must be 11 digits starting with 01")
                        address.isBlank() -> error = tr(lang, "اكتب العنوان", "Enter your address")
                        else -> {
                            error = null
                            onSave(Profile(name.trim(), p, address.trim()))
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
            ) {
                Text(tr(lang, "حفظ", "Save"), fontSize = 17.sp)
            }
        }
    }
}

// ================= Menu =================

@Composable
fun MenuScreen(
    lang: Lang,
    cart: SnapshotStateMap<String, Int>,
    onToggleLang: () -> Unit,
    onProfile: () -> Unit,
    onOpenCart: () -> Unit
) {
    var category by remember { mutableStateOf<String?>(null) }
    val categories = remember { MENU.map { it.categoryEn }.distinct() }
    val shown = MENU.filter { category == null || it.categoryEn == category }
    val count = cart.values.sum()
    val subtotal = cartSubtotal(cart)

    Column(modifier = Modifier.fillMaxSize()) {
        Header(tr(lang, Config.RESTAURANT_NAME_AR, Config.RESTAURANT_NAME_EN), lang, onToggleLang) {
            TextButton(onClick = onProfile) {
                Text(tr(lang, "بياناتي", "Profile"), color = Color.White)
            }
        }

        LazyRow(
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                CategoryButton(tr(lang, "الكل", "All"), category == null) { category = null }
            }
            items(categories) { c ->
                val sample = MENU.first { it.categoryEn == c }
                CategoryButton(tr(lang, sample.categoryAr, sample.categoryEn), category == c) { category = c }
            }
        }

        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(shown, key = { it.id }) { item ->
                MenuItemCard(
                    item = item,
                    lang = lang,
                    qty = cart[item.id] ?: 0,
                    onAdd = { addToCart(cart, item.id) },
                    onRemove = { removeFromCart(cart, item.id) }
                )
            }
        }

        if (count > 0) {
            Button(
                onClick = onOpenCart,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp)
                    .height(56.dp)
            ) {
                Text(
                    tr(lang, "السلة ($count) • ${money(subtotal, lang)}", "Cart ($count) • ${money(subtotal, lang)}"),
                    fontSize = 17.sp
                )
            }
        }
    }
}

@Composable
fun CategoryButton(label: String, selected: Boolean, onClick: () -> Unit) {
    if (selected) {
        Button(onClick = onClick) { Text(label) }
    } else {
        OutlinedButton(onClick = onClick) { Text(label) }
    }
}

@Composable
fun MenuItemCard(item: MenuItem, lang: Lang, qty: Int, onAdd: () -> Unit, onRemove: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(tr(lang, item.nameAr, item.nameEn), fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Spacer(Modifier.height(4.dp))
            Text(tr(lang, item.descAr, item.descEn), fontSize = 14.sp, color = Color.Gray)
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    money(item.price, lang),
                    fontWeight = FontWeight.Bold,
                    color = Brown,
                    fontSize = 16.sp,
                    modifier = Modifier.weight(1f)
                )
                QtyControl(qty, lang, onAdd, onRemove)
            }
        }
    }
}

// ================= Checkout =================

@Composable
fun CheckoutScreen(
    lang: Lang,
    cart: SnapshotStateMap<String, Int>,
    profile: Profile,
    onToggleLang: () -> Unit,
    onBack: () -> Unit,
    onEditProfile: () -> Unit,
    onSent: (String) -> Unit
) {
    val context = LocalContext.current
    var pay by remember { mutableStateOf(PayMethod.CASH) }
    var notes by remember { mutableStateOf("") }
    val subtotal = cartSubtotal(cart)
    val total = subtotal + Config.DELIVERY_FEE

    if (cart.isEmpty()) {
        LaunchedEffect(Unit) { onBack() }
        return
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Header(tr(lang, "تأكيد الطلب", "Checkout"), lang, onToggleLang, onBack = onBack)

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 14.dp)
        ) {
            // ---- Items ----
            SectionTitle(tr(lang, "طلبك", "Your order"))
            for ((id, q) in cart.entries.toList()) {
                val item = MENU_BY_ID[id] ?: continue
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(tr(lang, item.nameAr, item.nameEn), fontWeight = FontWeight.SemiBold)
                        Text(money(item.price * q, lang), color = Brown, fontSize = 14.sp)
                    }
                    QtyControl(q, lang, { addToCart(cart, id) }, { removeFromCart(cart, id) })
                }
            }
            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))
            AmountRow(tr(lang, "المجموع", "Subtotal"), money(subtotal, lang))
            AmountRow(tr(lang, "التوصيل", "Delivery"), money(Config.DELIVERY_FEE, lang))
            AmountRow(tr(lang, "الإجمالي", "Total"), money(total, lang), bold = true)

            // ---- Customer ----
            SectionTitle(tr(lang, "بيانات التوصيل", "Delivery details"))
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("👤 ${profile.name}")
                    Text("📞 ${profile.phone}")
                    Text("📍 ${profile.address}")
                    TextButton(onClick = onEditProfile) { Text(tr(lang, "تعديل البيانات", "Edit details")) }
                }
            }
            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text(tr(lang, "ملاحظات (اختياري)", "Notes (optional)")) },
                minLines = 2,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp)
            )

            // ---- Payment ----
            SectionTitle(tr(lang, "طريقة الدفع", "Payment method"))
            for (m in PayMethod.values()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .selectable(selected = pay == m, onClick = { pay = m })
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(selected = pay == m, onClick = { pay = m })
                    Text(payLabel(m, lang), fontSize = 16.sp)
                }
            }

            when (pay) {
                PayMethod.INSTAPAY -> {
                    Image(
                        painter = painterResource(id = R.drawable.instapay_qr),
                        contentDescription = "InstaPay QR",
                        modifier = Modifier
                            .size(230.dp)
                            .align(Alignment.CenterHorizontally)
                            .padding(top = 8.dp)
                    )
                    CopyRow(lang, Config.INSTAPAY_ADDRESS)
                    TransferHint(lang, money(total, lang))
                }

                PayMethod.WALLET -> {
                    CopyRow(lang, Config.WALLET_NUMBER)
                    TransferHint(lang, money(total, lang))
                }

                PayMethod.CASH -> {
                    Text(
                        tr(lang, "هتدفع ${money(total, lang)} للمندوب عند الاستلام", "You'll pay ${money(total, lang)} to the courier on delivery"),
                        color = Color.DarkGray,
                        modifier = Modifier.padding(8.dp)
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
        }

        Button(
            onClick = {
                val id = newOrderId()
                val msg = buildOrderMessage(id, profile, cart, notes, pay)
                if (openWhatsApp(context, Config.RESTAURANT_WHATSAPP, msg)) {
                    onSent(id)
                } else {
                    Toast.makeText(context, tr(lang, "مش قادر أفتح واتساب", "Couldn't open WhatsApp"), Toast.LENGTH_LONG).show()
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
                .height(56.dp)
        ) {
            Text(tr(lang, "إرسال الطلب على واتساب", "Send order via WhatsApp"), fontSize = 17.sp)
        }
    }
}

@Composable
fun CopyRow(lang: Lang, value: String) {
    val context = LocalContext.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            value,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.weight(1f)
        )
        OutlinedButton(onClick = { copyToClipboard(context, value, tr(lang, "تم النسخ", "Copied")) }) {
            Text(tr(lang, "نسخ", "Copy"))
        }
    }
}

@Composable
fun TransferHint(lang: Lang, total: String) {
    Text(
        tr(
            lang,
            "حوّل $total وابعت صورة التحويل في شات الواتساب بعد إرسال الطلب",
            "Transfer $total and send the transfer screenshot in the WhatsApp chat after sending the order"
        ),
        color = Color.DarkGray,
        fontSize = 14.sp,
        modifier = Modifier.padding(vertical = 8.dp)
    )
}

// ================= Done =================

@Composable
fun DoneScreen(lang: Lang, orderId: String, onToggleLang: () -> Unit, onNewOrder: () -> Unit) {
    Column(modifier = Modifier.fillMaxSize()) {
        Header(tr(lang, Config.RESTAURANT_NAME_AR, Config.RESTAURANT_NAME_EN), lang, onToggleLang)
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("✅", fontSize = 64.sp)
            Spacer(Modifier.height(12.dp))
            Text(
                tr(lang, "تم إرسال طلبك رقم #$orderId", "Your order #$orderId was sent"),
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(8.dp))
            Text(
                tr(
                    lang,
                    "المطعم هيراجع الطلب ويأكد معاك البيانات والدفع ومدة التوصيل على واتساب",
                    "The restaurant will confirm your details, payment and delivery time on WhatsApp"
                ),
                textAlign = TextAlign.Center,
                color = Color.DarkGray
            )
            Spacer(Modifier.height(24.dp))
            Button(onClick = onNewOrder) { Text(tr(lang, "طلب جديد", "New order")) }
        }
    }
}
