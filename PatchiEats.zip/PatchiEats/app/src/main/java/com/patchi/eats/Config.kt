package com.patchi.eats

// ✏️ كل الإعدادات اللي هتغيّرها موجودة هنا
object Config {
    const val RESTAURANT_NAME_AR = "باتشي كافيه"
    const val RESTAURANT_NAME_EN = "Patchi Café"

    // رقم واتساب المطعم بالصيغة الدولية من غير + ولا مسافات (مثال: 201001234567)
    const val RESTAURANT_WHATSAPP = "201000000000"

    // عنوان إنستاباي
    const val INSTAPAY_ADDRESS = "yourname@instapay"

    // رقم المحفظة (فودافون كاش / اتصالات كاش ...)
    const val WALLET_NUMBER = "01000000000"

    // رسوم التوصيل بالجنيه
    const val DELIVERY_FEE = 45.0
}
