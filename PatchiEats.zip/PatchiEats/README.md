# Patchi Eats

تطبيق طلبات لباتشي كافيه:
- منيو بالعربي والإنجليزي
- تسجيل بالاسم ورقم الموبايل والعنوان (بيتحفظ على الموبايل)
- الدفع: إنستاباي (QR) / محفظة / كاش عند الاستلام
- الطلب كامل بيتبعت على واتساب المطعم عشان يأكده

## ✏️ قبل ما تبني التطبيق غيّر الحاجات دي

1. **`app/src/main/java/com/patchi/eats/Config.kt`**
   - `RESTAURANT_WHATSAPP`: رقم واتساب المطعم (مثال: `201001234567`)
   - `INSTAPAY_ADDRESS`: عنوان إنستاباي
   - `WALLET_NUMBER`: رقم المحفظة
   - `DELIVERY_FEE`: رسوم التوصيل

2. **صورة QR إنستاباي**: حط صورتك مكان
   `app/src/main/res/drawable/instapay_qr.png`
   (بنفس الاسم بالظبط، حروف صغيرة).

3. **المنيو والأسعار**: `app/src/main/java/com/patchi/eats/Menu.kt`

## 📦 إزاي تطلّع ملف APK

### الطريقة الأولى: GitHub (من غير ما تنزّل أي برامج)
1. اعمل حساب على github.com، ومنه اعمل Repository جديد.
2. اضغط **uploading an existing file**، واسحب كل محتويات فولدر `PatchiEats`، وبعدين اضغط **Commit**.
   - ⚠️ لازم فولدر `.github` يترفع هو كمان. لو اتخفى عندك، اعمل ملف جديد من GitHub وسمّيه
     `.github/workflows/build-apk.yml` وانسخ فيه محتوى الملف.
3. روح لتبويب **Actions** واستنى البناء لحد ما يخلص (حوالي 5 دقايق وتلاقي علامة ✅).
4. افتح البناء، وتحت **Artifacts** نزّل **PatchiEats-APK**. هتلاقي جواه ملف `app-debug.apk`.

وكل ما تعدّل أي ملف على GitHub، هيطلعلك APK جديد لوحده.

### الطريقة التانية: Android Studio
افتح فولدر `PatchiEats` من Android Studio، وبعدين من القايمة اختار
**Build ▸ Build APK(s)**.
